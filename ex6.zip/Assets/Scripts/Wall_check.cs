using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall_check : MonoBehaviour
{

    Color transp = Color.white;
    // Start is called before the first frame update
    void Start()
    {
        transp.r = .8f;
        transp.g = 0.75f;
        transp.b = 0.75f;
        transp.a = 0.5f;

    }

    // Update is called once per frame
    void Update()
    {
        if (transform.parent.rotation != Quaternion.identity)
        {
            transform.rotation = Quaternion.Euler(0f, 0f, transform.parent.rotation.z * -1f);
        }
        else
        {
            transform.rotation = Quaternion.identity;
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        GameObject obj;
        if (collision != null)
        {
            obj = collision.gameObject;
            if (obj.tag == "Wall")
            {
                if (obj.GetComponent<SpriteRenderer>().color.a == 1f)
                {
                    obj.GetComponent<SpriteRenderer>().color = transp;
                }
            }
        }
        
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        GameObject obj;
        if (collision != null)
        {
            obj = collision.gameObject; 
            if (obj.tag =="Wall")
            {
                if (obj.GetComponent<SpriteRenderer>().color.a != 1f && obj.tag == "Wall")
                {
                    obj.GetComponent<SpriteRenderer>().color = Color.white;
                }
            }
            
        }
    }
}
