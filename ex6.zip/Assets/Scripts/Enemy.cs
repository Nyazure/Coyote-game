using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public int HP = 2;

    public float spd = 2;
    public float accel = 0.2f;
    public float fric = 0.3f;

    public float invuln_cooldown = 0.2f;
    public float invuln_timer = 0f;

    public float atk_cooldown = 0.8f;
    float atk_timer = 0;
    public float atk_spd = 5f;
    public float kb = 6f;

    public float flash = 0.2f;
    float flash_timer = 0f;
    float death_timer = 0f;

    public Rigidbody2D rb;
    public Transform player_check;
    public Player player;
    public Animator anim;

    public bool attack;
    public bool attacking = false;

    public Vector2 move;
    public Vector2 vel;
    public AnimatorStateInfo state => anim.GetCurrentAnimatorStateInfo(0);
    private Vector2 player_offset => player.rb.position - gameObject.GetComponent<Rigidbody2D>().position;
    private Vector2 player_dir => player_offset.normalized;

    Vector2 atk_dir;
    

    public GameObject BulletPrefab;
    void Start()
    {
        player = FindObjectOfType<Player>();
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        player_check = gameObject.transform.GetChild(0).GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        get_action();
        movement();
        if (state.IsName("death"))
        {
            rb.Sleep();
            GetComponent<Collider2D>().enabled = false;
        }
        if (attack && atk_timer == 0)
        {
            attacking = true;
            Attack();
        }
        if (state.IsName("attack"))
        {
            if (attacking) {
                GameObject b = Instantiate(BulletPrefab, transform.position + (transform.right * 0.5f), Quaternion.identity);
                Bullet bullet = b.GetComponent<Bullet>();
                bullet.is_melee = true;
                bullet.owner = gameObject.transform.GetChild(1).gameObject;
                bullet.dir = atk_dir;
                bullet.spd = spd;
                bullet.kb = kb;
                attacking = false;
            }
            if (transform.localScale.x > 0)
            {
                transform.rotation = Quaternion.FromToRotation(Vector3.right, atk_dir);
            }
            else
            {
                transform.rotation = Quaternion.FromToRotation(-Vector3.right, atk_dir);
            }
            
            rb.velocity = atk_dir * atk_spd;
        }
        else
        {
            transform.rotation = Quaternion.identity;
        }
        
    }
    private void FixedUpdate()
    {
        timers();
        
        if (!state.IsName("hurt"))
        if (vel.x > 0)
        {
            transform.localScale = new Vector3(4, 4, 1);
        }
        else if (vel.x < 0)
        {
            transform.localScale = new Vector3(-4, 4, 1);
        }
        transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.y);

        if (death_timer > 3f)
        {
            Destroy(gameObject);
        }

        
    }
    void timers()
    {
        if (state.IsName("hurt"))
        {
            atk_timer = 0;
        }
        if (state.IsName("death"))
        {
            death_timer += Time.fixedDeltaTime;
            if (death_timer > 1f)
            {
                flash_timer = Util.Approach(flash_timer, 0, Time.fixedDeltaTime);
                if (flash_timer < 0.1f)
                {
                    gameObject.GetComponent<SpriteRenderer>().color = new Color(1, 0.9f, 0.9f, 0.4f);
                }
                if (flash_timer == 0)
                {
                    flash_timer = flash;
                    gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                }
            }
        }

        atk_timer = Util.Approach(atk_timer, 0, Time.fixedDeltaTime);
        invuln_timer = Util.Approach(invuln_timer, 0, Time.fixedDeltaTime);
    }

    public void get_action()
    {
        if (!Player_found())
        {
            if (state.IsName("attack_startup") || state.IsName("hurt") || state.IsName("endlag"))
            {
                move = player_dir * 0.1f;
            }
            else if (state.IsName("death"))
            {
                move = Vector2.zero;
            }
            else
            {
                move = player_dir;
            }

        }
        else
        {
            move = new Vector2(0, 0);
        }
        if (Player_found() && !state.IsName("death"))
        {
            attack = true;
        }
        else
        {
            attack = false;
        }

    }
    void movement()
    {
        vel = rb.velocity;
        float accel_fric;
        if (move.magnitude != 0)
        {
            accel_fric = accel; ;

        }
        else
        {
            accel_fric = fric;
        }
        vel.x = Util.Approach(vel.x, move.x * spd, accel_fric);
        vel.y = Util.Approach(vel.y, move.y * spd, accel_fric);


        rb.velocity = vel;

        if (rb.velocity.magnitude > 0.2)
        {
            anim.SetBool("moving", true);
        }
        else
        {
            anim.SetBool("moving", false);
        }
    }
    public void Attack()
    {
        anim.SetBool("attack", true);
        atk_dir = player_dir;
        atk_timer = atk_cooldown;
        
    }

        private bool Player_found()
    {
        return Physics2D.OverlapCircle(player_check.position, 1f, LayerMask.GetMask("Player"));
    }
    public void Damage(Vector2 _kb)
    {
        if (invuln_timer == 0)
        {
            rb.velocity = _kb;
            anim.SetBool("hurt", true);
            invuln_timer = invuln_cooldown;
            if (HP > 0)
            {
                HP--;
                
            }
            if (HP == 0)
            {
                anim.SetBool("death", true);
                ScoreKeeper.ScorePoints(5);
            }

        }
    }

}
