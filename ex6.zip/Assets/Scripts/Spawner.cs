using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject enemy;
    float spawn_interval = 20f;
    float spawn_timer;
    float rand_chance => Random.Range(0f, 1f);
    float spawn_chance = 0.05f;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (spawn_timer == 0)
        {
            spawn_interval = Util.Approach(spawn_interval, 4f, 0.1f);
            if (spawn_interval == 4)
            {
                spawn_chance = Util.Approach(spawn_chance, 0.3f, 0.05f);
            }
        }

    }
    private void FixedUpdate()
    {
        spawn_timer = Util.Approach(spawn_timer, 0, Time.deltaTime);
        if (spawn_timer == 0 && rand_chance < spawn_chance && PointFree())
        {
            Instantiate(enemy, transform.position, Quaternion.identity);
            spawn_timer = spawn_interval;
        }
        
    }
    bool PointFree()
    {
        return Physics2D.CircleCast(transform.position, 1f, transform.right, 0);
    }
}
