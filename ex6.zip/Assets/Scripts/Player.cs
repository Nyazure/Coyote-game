using System.Collections;
using System.Collections.Generic;
using Unity.IO.LowLevel.Unsafe;
using UnityEngine;

public class Player : MonoBehaviour
{
    public int HP = 3;

    public float spd = 3;
    public float accel = 0.2f;
    public float fric = 0.3f;

    public float invuln_cooldown = 0.7f;
    public float invuln_timer = 0f;

    public float shoot_cooldown = 0.6f;
    public float shoot_timer = 0;

    public float bullet_spd = 5;

    public Rigidbody2D rb;
    public Camera cam;
    public Animator anim;
    Gun gun;
    float rand_chance => Random.Range(0f, 1f);
    public AnimatorStateInfo state => anim.GetCurrentAnimatorStateInfo(0);

    public int score_count = 25;

    float death_timer = 0;

    public Vector2 move;
    public Vector2 vel;
    public Vector2 mouse_pos;
    public Vector2 look_dir;
    public bool shoot;

    public GameObject end;
    public GameObject VFXPrefab;
    public AudioClip power;
    AudioSource source;

    void Start()
    {
        gun = GetComponentInChildren<Gun>();
        source = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        get_inputs();
        movement();
        if (ScoreKeeper.Singleton.Score >= score_count)
        {
            shoot_cooldown = Util.Approach(shoot_cooldown, 0.1f, 0.05f);
            source.PlayOneShot(power);
            GameObject vfx_obj = Instantiate(VFXPrefab, transform.position + (transform.forward), Quaternion.identity);
            vfx_obj.GetComponent<Animator>().SetBool("power", true);
            score_count += 25;
        }

        transform.GetChild(3).GetComponent<SpriteRenderer>().enabled = (HP == 1);
        
        if (shoot && shoot_timer == 0)
        {
            shoot_timer = shoot_cooldown;
            gun.Shoot();
        }
        if (state.IsName("death"))
        {
            rb.Sleep();
            GetComponent<Collider2D>().enabled = false;
            if (death_timer > 4f)
            {
                end.SetActive(true);
                Time.timeScale = Util.Approach(Time.timeScale, 0, 0.1f);
            }
        }
        if (state.IsName("run"))
        {
            if (rand_chance < 0.05f)
            {
                GameObject vfx_obj = Instantiate(VFXPrefab, transform.position + (-transform.up * Random.Range(0.2f, 0.16f)) + (transform.forward), Quaternion.identity);
                vfx_obj.GetComponent<Animator>().speed = Random.Range(1f, 2f);
                vfx_obj.GetComponent<Animator>().SetBool("dust", true);
                
                
            }
        }
    }
    
    void FixedUpdate()
    {
        timers();
        look_dir = (mouse_pos - rb.position);
        if (look_dir.normalized.x > 0.2f)
            transform.localScale = new Vector3(4, 4, 1);
        else if (look_dir.normalized.x < -0.2f)
        {
            transform.localScale = new Vector3(-4, 4, 1);
        }
        transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.y);
    }
    void timers()
    {
        if (state.IsName("hurt"))
        {
            shoot_timer = 0;
        }
        if (state.IsName("death"))
        {
            death_timer += Time.fixedDeltaTime;
        }

        shoot_timer = Util.Approach(shoot_timer, 0, Time.fixedDeltaTime);
        invuln_timer = Util.Approach(invuln_timer, 0, Time.fixedDeltaTime);
    }
    void get_inputs()
    {
        move.x = Input.GetAxisRaw("Horizontal");
        move.y = Input.GetAxisRaw("Vertical");
        move = move.normalized;
        if (!state.IsName("hurt") && !state.IsName("death"))
        {
            shoot = Input.GetMouseButton(0);
            
        }
        else if (state.IsName("hurt"))
        {
            move *= 0.2f;
        }
        else
        {
            move = Vector2.zero;
        }
        

        mouse_pos = cam.ScreenToWorldPoint(Input.mousePosition);
        
    }
    void movement()
    {
        vel = rb.velocity;
        float accel_fric;
        if (move.magnitude != 0)
        {
            accel_fric = accel;
            
        }
        else
        {
            accel_fric = fric;
        }
        vel.x = Util.Approach(vel.x, move.x * spd, accel_fric);
        vel.y = Util.Approach(vel.y, move.y * spd, accel_fric);


        rb.velocity =  vel;
        
        if (vel.magnitude > 0.2)
        {
            anim.SetBool("moving", true);
        }
        else
        {
            anim.SetBool("moving", false);
        }
    }
    public void Damage(Vector2 _kb)
    {
        if (invuln_timer == 0)
        {
            rb.velocity = _kb;
            anim.SetBool("hurt", true);
            invuln_timer = invuln_cooldown;
            if (HP > 0)
            {
                HP--;

            }
            if (HP == 0)
            {
                anim.SetBool("death", true);
            }

        }
    }

}
