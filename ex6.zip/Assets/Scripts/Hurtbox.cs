using System.Collections;
using System.Collections.Generic;
using Unity.Burst.CompilerServices;
using UnityEngine;
using static Unity.VisualScripting.Member;

public class Hurtbox : MonoBehaviour
{
    // Start is called before the first frame update
    Player player;
    Enemy enemy;
    public GameObject VFXPrefab;

    public AudioClip hit;
    AudioSource source;
    void Start()
    {
        source = GetComponent<AudioSource>();
        if (transform.parent.tag == "Player")
        {
            player = GetComponentInParent<Player>();
        }
        else
        {
            enemy = GetComponentInParent<Enemy>();
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void dmg(Vector2 kb)
    {
        source.PlayOneShot(hit);
        if (player != null)
        {
  
            player.Damage(kb);
        }
        else if (enemy != null)
        {

            enemy.Damage(kb);
        }
    }

    public bool is_hurt()
    {
        if (player != null)
        {
            return (player.invuln_timer > 0 || player.state.IsName("death"));
        }
        else if (enemy != null)
        {
            return (enemy.invuln_timer > 0 || enemy.state.IsName("death"));
        }
        return true;
    }
    public void vfx()
    {
        GameObject vfx_obj = Instantiate(VFXPrefab, transform.parent.position - transform.forward * 0.1f, Quaternion.identity);
        
        if (player != null)
        {
            vfx_obj.GetComponent<Animator>().SetBool("hit", true);
        }
        else if (enemy != null)
        {
            vfx_obj.GetComponent<Animator>().SetBool("explode", true);
        }
    }



}
