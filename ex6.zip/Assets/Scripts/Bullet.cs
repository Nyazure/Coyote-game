using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using Unity.VisualScripting;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    // Start is called before the first frame update
    public bool is_melee;
    
    public GameObject owner;
    public Animator owner_anim;
    public AnimatorStateInfo owner_state;
    public Vector3 owner_position;
    //public Rigidbody2D rb;
    public float kb;
    public float lifetime;
    public bool front = true;
    Vector2 opp_offset;
    bool strike = false;
    public GameObject vfxPrefab;

    public Animator anim;
    public AnimatorStateInfo state => anim.GetCurrentAnimatorStateInfo(0);
    public AnimatorStateInfo state_melee;
    public Vector3 dir;
    public float spd;


    void Start()
    {
        anim = GetComponent<Animator>();
        if (is_melee)
        {
            transform.localScale = new Vector3(10f, 10f, 1);
            GetComponent<SpriteRenderer>().color = new Color(0, 0, 0, 0);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (state.IsName("destroy"))
        {
            Destroy(gameObject);
        }
        if (is_melee && !owner.GetComponentInParent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("attack"))
        {
            Destroy(gameObject);
        }
    }
    void FixedUpdate()
    {
       
        if (!strike)
        {
            if (is_melee)
            {
                transform.position = owner.transform.position;
            }
            else
            {
                transform.position += spd * dir * Time.fixedDeltaTime;
            }
        }
        transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.y - 0.01f);
        
        
    }
    private void OnBecameInvisible()
    {
        Destroy(gameObject);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        Hurtbox hit;
        if (collision.tag == "Wall" && !is_melee)
        {
            strike = true;
            anim.SetBool("break", true);

        }
        if (collision.tag == "Hurtbox" && !strike)
        {
            hit = collision.gameObject.GetComponent<Hurtbox>();
            if (hit.transform.parent.tag != owner.transform.parent.tag)
            {
                if (!hit.is_hurt())
                {
                    strike = true;
                    anim.SetBool("break", true);
                    hit.dmg(dir * kb);
                    hit.vfx();

                }
            }
            
        }
    }
}
